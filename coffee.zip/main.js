function addOpinion() {
  const input = document.getElementById("inputOpinion");
  const list = document.getElementById("opinion");
  const value = input.value.trim();
  
  if (value !== "") {
    const li = document.createElement("li");
    li.textContent = value;
    list.appendChild(li);
    input.value = "";
  }
}